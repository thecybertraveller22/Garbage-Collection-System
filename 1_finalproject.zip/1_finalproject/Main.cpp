#include <iostream>
#include <utility>
#include <ctime>
#include <string.h>
#include <string>
#include <climits>
#include <cstdlib>
#include <istream>
#include <fstream>
#include <stdlib.h>
#include <iomanip>
#include <conio.h>

using namespace std;

class Truck_Driver
{
private:
    string Truck_name;
    int age;
    string username;
    string password;
public:

    string getTruck_Driver_name()
    {
        return Truck_name;
    }
    bool truckLogin(string &s)
    {
        password = "";
        int count = 0;
        bool login_success = false;
        string u, p;

        system("cls");
        cout << " Enter the following details" << endl;
        cout << "USERNAME: ";
        cin >> username;
        cout << "PASSWORD: ";

        char c;
        while ((c = _getch()) != 13)
        {
            if (c != 8)
            { 
                password += c;
                cout << '*'; 
            }
            else
            {
                if (!password.empty())
                {
                    password.pop_back();
                    cout << "\b \b";
                }
            }
        }


        ifstream input("truckdatabase.txt");
        while (input >> u >> p)
        {
            if (u == username && p == password)
            {
                string email;
                ifstream userData("truckdata.txt");

                while (userData >> email >> Truck_name >> age)
                {

                    if (email == username)
                    {

                        cout << "Welcome back, " << Truck_name << "!\n";
                        cout << "Your age is: " << age << "\n";
                        login_success = true;
                        s = username;
                        break;
                    }

                }
                userData.close();             
                break;
            }
        }
        input.close();

        if (!login_success)
        {
            cout << "\nLOGIN ERROR\nPlease check your username and password\n";
        }
        return login_success;
    }
    void TruckRegister()
    {
        string reguser, regpass;
        bool usernameExists = false;

        system("cls");
        cout << "Enter the username: ";
        cin >> reguser;
        cout << "Enter your name: ";
        cin >> Truck_name;
        cout << "Enter your age: ";
        cin >> age;
        cout << "\nEnter the password: ";

        char c;
        while ((c = _getch()) != 13)
        {
            if (c != 8)
            {
                regpass += c;
                cout << '*';
            }
            else if (!regpass.empty())
            {
                regpass.pop_back();
                cout << "\b \b";
            }
        }

        if (reguser.empty() || regpass.empty())
        {
            cout << "\nInvalid username or password. Please try again.\n";
            return;
        }

        ifstream input("truckdatabase.txt");
        string u, p;
        while (input >> u >> p)
        {
            if (u == reguser)
            {
                usernameExists = true;
                break;
            }
        }
        input.close();

        if (usernameExists)
        {
            cout << "\nUsername is already taken. Please choose a different one.\n";
        }

        ofstream reg("truckdatabase.txt", ios::app);
        reg << reguser << ' ' << regpass << endl;
        reg.close();

        
        cout << "Registered user details:\n";
        cout << "Username: " << reguser << "\n";
        cout << "Password: " << regpass << "\n";
        cout << "Truck Name: " << Truck_name << "\n";
        cout << "Age: " << age << "\n";

        ofstream userData("truckdata.txt", ios::app);
        userData << reguser << ' ' << Truck_name << ' ' << age << endl;
        userData.close();

        system("cls");
        cout << "\nRegistration successful.\n";
    }


    void TruckForgot()
    {
        int ch;
        system("cls");
        cout << "Forgotten? We're here to help\n";
        cout << "1. Search your id by username\n";
        cout << "2. Search your id by password\n";
        cout << "3. Main menu\n";
        cout << "Enter your choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1: 
        {
            int count = 0;
            string searchuser, su, sp;
            cout << "\nEnter your remembered username: ";
            cin >> searchuser;

            ifstream searchu("truckdatabase.txt");
            while (searchu >> su >> sp)
            {
                if (su == searchuser) 
                {
                    count = 1;
                    break;
                }
            }
            searchu.close();

            if (count == 1) 
            {
                cout << "\n\nHurray, account found\n";
                cout << "\nYour password is " << sp;
                cin.get();
                cin.get();
                system("cls");
            }
            else 
            {
                cout << "\nSorry, your userID is not found in our database\n";
                cout << "\nPlease kindly contact your system administrator for more details \n";
                cin.get();
                cin.get();
            }
            break;
        }
        case 2: 
        {
            int count = 0;
            string searchpass, su2, sp2;
            cout << "\nEnter the remembered password: ";
            cin >> searchpass;

            ifstream searchp("truckdatabase.txt");
            while (searchp >> su2 >> sp2) 
            {
                if (sp2 == searchpass) 
                {
                    count = 1;
                    break;
                }
            }
            searchp.close();

            if (count == 1) 
            {
                cout << "\nYour password is found in the database \n";
                cout << "\nYour Id is: " << su2;
                cin.get();
                cin.get();
                system("cls");
            }
            else 
            {
                cout << "Sorry, we cannot find your password in our database \n";
                cout << "\nKindly contact your administrator for more information\n";
                cin.get();
                cin.get();
            }
            break;
        }
        case 3: 
        {
            cin.get();
            break;
        }
        default:
            cout << "Sorry, you entered the wrong choice. Kindly try again" << endl;
        }
    }
    void checkRoute(string email)
    {
        ifstream read("work.txt");

		if (!read.is_open())
        {
			cout << "Error opening file!" << endl;
			return;
		}
        string temp, path;

        while (!read.eof())
        {
            getline(read, temp, ',');
            if (temp == email)
            {
                getline(read, path, '\n');
				cout << "Path is = " << path << endl;
            }         
        }
    }

};


class Vertex
{
public:

    Vertex() {}

    Vertex(int id, const string& address, int garbageAmount) : id(id), address(address), garbageAmount(garbageAmount)
    {
        if (garbageAmount < 0)
        {
            garbageAmount = 0;
        }
    }

    int getId() const
    {
        return id;
    }

    string getAddress() const
    {
        return address;
    }

    int getGarbageAmount() const
    {
        return garbageAmount;
    }

    void setGarbageAmount(int amount)
    {
        if (amount >= 0)
        {
            garbageAmount = amount;
        }
    }

private:
    int id;
    string address;
    int garbageAmount;
};

class Graph
{
public:
    Graph(int type, int vertices) : V(vertices)
    {
        if (type == 1)
        {
            initializeVertices();
        }
        else if (type == 2)
        {
            initializeVertices2();
        }
        else if (type == 3)
        {
            initializeVertices3();
        }
        else if (type == 4)
        {
            initializeVertices4();
        }
        else if (type == 5)
        {
            initializeVertices5();
        }

        initializeAdjMatrix();
    }

    void addEdge(int u, int v, int weight)
    {
        adjMatrix[u][v] = weight;
        adjMatrix[v][u] = weight;
    }
    int getVerticesCount() const
    {
        return V;
    }
    const Vertex& getVertexById(int id) const
    {
        if (id >= 0 && id < V)
        {
            return vertices[id];
        }

    }


    void printGraph() const
    {
        for (int v = 0; v < V; ++v)
        {
            if (vertices[v].getId() == 0)
            {
                cout << "Truck Departure at " << vertices[v].getAddress() << endl;
            }
            else if (vertices[v].getId() == 11)
            {
                cout << "Dump at " << vertices[v].getAddress() << endl;
            }
            else
            {
                cout << "Bin " << vertices[v].getId() << " at " << vertices[v].getAddress()
                    << " (Garbage Amount: " << vertices[v].getGarbageAmount() << ") is connected to:\n";
            }

            for (int neighbor = 0; neighbor < V; ++neighbor)
            {
                if (adjMatrix[v][neighbor] > 0)
                {
                    cout << vertices[neighbor].getAddress() << " (Weight: " << adjMatrix[v][neighbor] << ")\n";
                }
            }
            cout << endl;
        }
    }





    void dijkstra(int start, int end)
    {
        int count = 0;
        for (int i = 1; i < V; i++)
        {
            if (vertices[i].getGarbageAmount() < 75)
            {
                count++;
            }
            if (count >= 11)
            {
                cout << "There are no bins to collect today" << endl;
                return;
            }
        }

        int* dist = new int[V];
        int* parent = new int[V];
        bool* visited = new bool[V];

        for (int i = 0; i < V; ++i)
        {
            dist[i] = INT_MAX;
            parent[i] = -1;
            visited[i] = false;
        }

        dist[start] = 0;

        for (int count = 0; count < V - 1; ++count)
        {
            int u = minDistance(dist, visited);

            visited[u] = true;

            for (int v = 0; v < V; ++v)
            {
                if (!visited[v] && adjMatrix[u][v] && dist[u] != INT_MAX && dist[u] + adjMatrix[u][v] < dist[v])
                {
                    dist[v] = dist[u] + adjMatrix[u][v];
                    parent[v] = u;
                }
            }
        }


        int current = end;
        cout << "Shortest path from " << vertices[start].getAddress() << " to " << vertices[end].getAddress() << ": ";
        if (dist[end] == INT_MAX)
        {
            cout << "No path found." << endl;
        }
        else
        {
            while (current != -1)
            {
                cout << vertices[current].getAddress() << " (" << current << ")";
                if (parent[current] != -1)
                    cout << " <- ";
                current = parent[current];
            }
            cout << "\nTotal distance: " << dist[end] << endl;
        }

        delete[] dist;
        delete[] parent;
        delete[] visited;

    }

    int minDistance(int* dist, bool* visited)
    {
        int minDist = INT_MAX, minIndex;

        for (int v = 0; v < V; ++v)
        {
            if (!visited[v] && dist[v] < minDist)
            {
                minDist = dist[v];
                minIndex = v;
            }
        }

        return minIndex;
    }


    void pathfinder()
    {
        int start = 0; 
        int end = 11;  

        for (int i = 0; i < V; i++)
        {
            if (vertices[i].getId() != 0 && vertices[i].getId() != 11 && vertices[i].getGarbageAmount() >= 75)
            {
                dijkstra(start, i);
                start = i;
            }
            else if (vertices[i].getId() == 11)
            {
                dijkstra(start, end);
            }
        }
    }

    void updateBins()
    {
        for (int i = 1; i < 12; i++)
        {
            if (vertices[i].getGarbageAmount() < 75)
                vertices[i].setGarbageAmount((1 + rand() % 101));
            else if (vertices[i].getGarbageAmount() >= 75 && vertices[i].getGarbageAmount() < 100)
                vertices[i].setGarbageAmount(vertices[i].getGarbageAmount() + 1);
        }
    }
    void updateWeight()
    {
        for (int i = 0; i < V; ++i)
        {
            for (int j = 0; j < V; ++j)
            {
                if (adjMatrix[i][j] != 0)
                {
                    if (rand() % 2)
                    {
                        if (rand() % 2)
                            adjMatrix[i][j] += 1;
                        else
                            adjMatrix[i][j] += -1;
                    }
                }
            }
        }
    }
    void emptyBins()
    {
        for (int i = 1; i < V; i++)
        {
            if (vertices[i].getGarbageAmount() >= 75)
            {
                vertices[i].setGarbageAmount(0);
            }
        }
    }


private:
    int V;
    int** adjMatrix;
    Vertex* vertices;

    void initializeVertices()
    {
        srand(static_cast<unsigned>(time(0)));
        vertices = new Vertex[V];

        for (int i = 0; i < V; ++i)
        {
            string address = generateAddress(i);
            int garbageAmount = 1 + rand() % 101;
            vertices[i] = Vertex(i, address, garbageAmount);
        }
    }

    void initializeVertices2()
    {
        srand(static_cast<unsigned>(time(0)));
        vertices = new Vertex[V];

        for (int i = 0; i < V; ++i)
        {

            string address = generateAddress2(i);
            int garbageAmount = 1 + rand() % 101; // This is where garbage amount is generated 
            vertices[i] = Vertex(i, address, garbageAmount);
        }
    }

    void initializeVertices3()
    {
        srand(static_cast<unsigned>(time(0)));
        vertices = new Vertex[V];

        for (int i = 0; i < V; ++i)
        {

            string address = generateAddress3(i);
            int garbageAmount = 1 + rand() % 101;
            vertices[i] = Vertex(i, address, garbageAmount);
        }
    }
    void initializeVertices4()
    {
        srand(static_cast<unsigned>(time(0)));
        vertices = new Vertex[V];

        for (int i = 0; i < V; ++i)
        {

            string address = generateAddress4(i);
            int garbageAmount = 1 + rand() % 101;
            vertices[i] = Vertex(i, address, garbageAmount);
        }
    }
    void initializeVertices5()
    {
        srand(static_cast<unsigned>(time(0)));
        vertices = new Vertex[V];

        for (int i = 0; i < V; ++i)
        {

            string address = generateAddress5(i);
            int garbageAmount = 1 + rand() % 101;
            vertices[i] = Vertex(i, address, garbageAmount);
        }
    }


    void initializeAdjMatrix()
    {
        adjMatrix = new int* [V];
        for (int i = 0; i < V; ++i)
        {
            adjMatrix[i] = new int[V];
            for (int j = 0; j < V; ++j)
            {
                adjMatrix[i][j] = 0; // weight yahan ho rha 0
            }
        }
    }


    string generateAddress3(int vertexId) const
    {
        ifstream file("Address3.csv");
        string address;

        if (file.is_open())
        {
            for (int i = 0; i <= vertexId; ++i)
            {
                if (!getline(file, address, ','))
                {
                    cout << "Error: Address not found for vertexId " << vertexId << endl;
                    file.close();
                    return "";
                }
            }

            file.close();
            return address;
        }
        else
        {
            cout << "Unable to open Address.csv" << endl;
            return "";
        }

        return "";

    }

    string generateAddress4(int vertexId) const
    {

        ifstream file("Address4.csv");
        string address;

        if (file.is_open())
        {
            for (int i = 0; i <= vertexId; ++i)
            {
                if (!getline(file, address, ','))
                {
                    cout << "Error: Address not found for vertexId " << vertexId << endl;
                    file.close();
                    return "";
                }
            }

            file.close();
            return address;
        }
        else
        {
            cout << "Unable to open Address.csv" << endl;
            return "";
        }

        return "";

    }
    string generateAddress5(int vertexId) const
    {


        ifstream file("Address5.csv");
        string address;

        if (file.is_open())
        {
            for (int i = 0; i <= vertexId; ++i)
            {
                if (!getline(file, address, ','))
                {
                    cout << "Error: Address not found for vertexId " << vertexId << endl;
                    file.close();
                    return "";
                }
            }

            file.close();
            return address;
        }
        else
        {
            cout << "Unable to open Address.csv" << endl;
            return "";
        }


        return "";

    }









    string generateAddress2(int vertexId) const
    {


        ifstream file("Address2.csv");
        string address;

        if (file.is_open())
        {
            for (int i = 0; i <= vertexId; ++i)
            {
                if (!getline(file, address, ','))
                {
                    cout << "Error: Address not found for vertexId " << vertexId << endl;
                    file.close();
                    return "";
                }
            }

            file.close();
            return address;
        }
        else
        {
            cout << "Unable to open Address.csv" << endl;
            return "";
        }

        return "";

    }



    string generateAddress(int vertexId) const
    {


        ifstream file("Address.csv");
        string address;

        if (file.is_open())
        {
            for (int i = 0; i <= vertexId; ++i)
            {
                if (!getline(file, address, ','))
                {
                    cout << "Error: Address not found for vertexId " << vertexId << endl;
                    file.close();
                    return "";
                }
            }

            file.close();
            return address;
        }
        else
        {
            cout << "Unable to open Address.csv" << endl;
            return "";
        }

        return "";
    }

};


class Controller
{
private:
    string name;
    int age;
    string user;
    string pass;
    Truck_Driver* drivers;

public:
    Controller()
    {

    }

    Controller(Truck_Driver* input)
    {
        drivers = input;
    }

	void alert(Graph& graph)
	{
		for (int i = 0; i < graph.getVerticesCount(); ++i)
		{
			if (graph.getVertexById(i).getId() != 0 && graph.getVertexById(i).getId() != 11 &&
				graph.getVertexById(i).getGarbageAmount() > 75)
			{
				cout << "Alert: Bin " << graph.getVertexById(i).getId() << " at "
					<< graph.getVertexById(i).getAddress() << " has garbage amount: "
					<< graph.getVertexById(i).getGarbageAmount() << endl;
			}
		}
	}

    bool controllerLogin(string &s)
    {
        pass = "";
        bool login_success = false;
        int count = 0;
        string u, p;

        system("cls");
        cout << "Please enter the following details" << endl;
        cout << "USERNAME: ";
        cin >> user;
        cout << "PASSWORD: ";
        //string pass;
        char c;
        while ((c = _getch()) != 13)
        {
            if (c != 8)
            { 
                pass += c;
                cout << '*'; 
            }
            else
            {
                if (!pass.empty())
                {
                    pass.pop_back();
                    cout << "\b \b";
                }
            }
        }

        ifstream input("database.txt");
        while (input >> u >> p)
        {
            if (u == user && p == pass)
            {
                count = 1;
                system("cls");
                string email;
                ifstream userData("userdata.txt");

                while (userData >> email >> name >> age)
                {

                    if (email == user)
                    {

                        cout << "Welcome back, " << name << "!\n";
                        cout << "Your age is: " << age << "\n";
                        login_success = true;
                        s = user;
                        break;
                    }
                }
                userData.close();

            }

        }
        input.close();

        if (count == 0)
        {
            cout << "\nLOGIN ERROR\nPlease check your username and password\n";
        }

        return login_success;
    }



    void controllerRegister() 
    {
        string reguser, regpass;
        bool usernameExists = false;

        system("cls");
        cout << "Enter the username: ";
        cin >> reguser;
        cout << "Enter your name: ";
        cin >> name;
        cout << "Enter your age: ";
        cin >> age;
        cout << "\nEnter the password: ";

        char c;
        while ((c = _getch()) != 13) 
        {
            if (c != 8)
            {
                regpass += c;
                cout << '*';
            }
            else if (!regpass.empty()) 
            {
                regpass.pop_back();
                cout << "\b \b";
            }
        }

        if (reguser.empty() || regpass.empty())
        {
            cout << "\nInvalid username or password. Please try again.\n";
            return;
        }

        ifstream input("database.txt");
        string u, p;
        while (input >> u >> p) 
        {
            if (u == reguser) 
            {
                usernameExists = true;
                break;
            }
        }
        input.close();

        if (usernameExists) 
        {
            cout << "\nUsername is already taken. Please choose a different one.\n";
        }

        ofstream reg("database.txt", ios::app);
        reg << reguser << ' ' << regpass << endl;
        reg.close();

        // Storing user data in userdata.txt
        ofstream userData("userdata.txt", ios::app);
        userData << reguser << ' ' << name << ' ' << age << endl;
        userData.close();

        system("cls");
        cout << "\nRegistration successful.\n";
    }

    void controllerForgot()
    {
        int ch;
        system("cls");
        cout << "Forgotten? We're here to help\n";
        cout << "1. Search your id by username\n";
        cout << "2. Search your id by password\n";
        cout << "3. Main menu\n";
        cout << "Enter your choice: ";
        cin >> ch;

        switch (ch) {
        case 1: {
            int count = 0;
            string searchuser, su, sp;
            cout << "\nEnter your remembered username: ";
            cin >> searchuser;

            ifstream searchu("database.txt");
            while (searchu >> su >> sp) 
            {
                if (su == searchuser) 
                {
                    count = 1;
                    break;
                }
            }
            searchu.close();

            if (count == 1)
            {
                cout << "\n\nHurray, account found\n";
                cout << "\nYour password is " << sp;
                cin.get();
                cin.get();
                system("cls");
            }
            else 
            {
                cout << "\nSorry, your userID is not found in our database\n";
                cout << "\nPlease kindly contact your system administrator for more details \n";
                cin.get();
                cin.get();
            }
            break;
        }
        case 2: 
        {
            int count = 0;
            string searchpass, su2, sp2;
            cout << "\nEnter the remembered password: ";
            cin >> searchpass;

            ifstream searchp("database.txt");
            while (searchp >> su2 >> sp2) 
            {
                if (sp2 == searchpass) 
                {
                    count = 1;
                    break;
                }
            }
            searchp.close();

            if (count == 1) 
            {
                cout << "\nYour password is found in the database \n";
                cout << "\nYour Id is: " << su2;
                cin.get();
                cin.get();
                system("cls");
            }
            else {
                cout << "Sorry, we cannot find your password in our database \n";
                cout << "\nKindly contact your administrator for more information\n";
                cin.get();
                cin.get();
            }
            break;
        }
        case 3:
        {
            cin.get();
            break;
        }
        default:
            cout << "Sorry, you entered the wrong choice. Kindly try again" << endl;
        }
    }

    
};




int main()
{
    Controller c;
    Truck_Driver t;

    int V = 12;
    Graph graph(1, V);  // f-11 wala area
    Graph graph2(2, V); // G sectors
    Graph graph3(3, V); // I secotrs
    Graph graph4(4, V); // Aur koi ilaka
    Graph graph5(5, V); // Taxila side

    int area_choice = 1212212;

    srand(static_cast<unsigned>(time(0)));

    for (int i = 0; i < V; ++i)
    {
        for (int j = i + 1; j < V; ++j)
        {
            int weight = 1 + rand() % 10;
            graph.addEdge(i, j, weight);
        }
    }

    //Graph 2	
    for (int i = 0; i < V; ++i)
    {
        for (int j = i + 1; j < V; ++j)
        {
            int weight = 1 + rand() % 10;
            graph2.addEdge(i, j, weight);
        }
    }

    //Graph3
    for (int i = 0; i < V; ++i)
    {
        for (int j = i + 1; j < V; ++j)
        {
            int weight = 1 + rand() % 10;
            graph3.addEdge(i, j, weight);
        }
    }

    //Graph4
    for (int i = 0; i < V; ++i)
    {
        for (int j = i + 1; j < V; ++j)
        {
            int weight = 1 + rand() % 10;
            graph4.addEdge(i, j, weight);
        }
    }


    //Graph5
    for (int i = 0; i < V; ++i)
    {
        for (int j = i + 1; j < V; ++j)
        {
            int weight = 1 + rand() % 10;
            graph5.addEdge(i, j, weight);
        }
    }
    
    int userType = -1; // -1: Not logged in, 1: Controller, 2: Truck Driver
    
    while (1)
    {
        cout << "Are you a:" << endl;
        cout << "1. Controller" << endl;
        cout << "2. Truck Driver" << endl;
        cout << "0. Exit" << endl;
        int roleChoice;
        cin >> roleChoice;

        if (roleChoice == 1)
        {
            userType = 1; // Controller
        }
        else if (roleChoice == 2)
        {
            userType = 2; // Truck Driver
        }
        else if (roleChoice == 0)
        {
            return 10;
        }
        else
        {
            system("CLS");
            cout << "Invalid input! Try Again" << endl;
            continue;
        }


        system("CLS");
        string s = "";

        int count = 0;
        bool exitFlag = false;
        while (!exitFlag)
        {
            int choice = -1;
            if (count == 0)
            {
                cout << "1. Login" << endl;
                cout << "2. Forgot Login Details" << endl;
                cout << "3. Register" << endl;
                cout << "0. Exit" << endl;
                cin >> choice;

                if (choice == 1)
                {
                    if (userType == 1)
                    {
                        if (c.controllerLogin(s))
                        {
                            cout << "Controller logged in." << endl;
                        }
                        else
                        {
                            cout << "Login failed. Please try again." << endl;
                            continue; // Go back to the main menu
                        }
                    }
                    else if (userType == 2)
                    {
                        if (t.truckLogin(s))
                        {
                            cout << "Truck Driver logged in." << endl;
                        }
                        else
                        {
                            cout << "Login failed. Please try again." << endl;
                            continue; // Go back to the main menu
                        }
                        // cout << "HELO" << endl;
                    }
                }
                else if (choice == 2)
                {
                    if (userType == 1)
                    {
                        c.controllerForgot();
                    }
                    else if (userType == 2)
                    {
                        t.TruckForgot();
                    }
                }
                else if (choice == 3)
                {
                    if (userType == 1)
                    {
                        c.controllerRegister();
                    }
                    else if (userType == 2)
                    {
                        t.TruckRegister();
                    }
                }
                else if (choice == 0)
                {
                    cout << "Closing Program................................" << endl;
                    break;
                }
                count++;
            }

            if (userType == 1)
            {
                int temp = -1;
                cout << "1. View bins\n2. View Alerts\n0. Logout\n";
                cin >> temp;
                if (temp == 1)
                {
                    cout << "Which area you want to view ? " << endl;
                    cout << "1. F-11 Area" << endl;
                    cout << "2. G sectors" << endl;
                    cout << "3. I sectors" << endl;
                    cout << "4. H sectors" << endl;
                    cout << "5. Taxila Side" << endl;
                    cout << "6.Check Alerts" << endl;
                    cin >> area_choice;

                    if (area_choice == 1)
                    {
                        while (1)
                        {
                            cout << "1. Print Graph" << endl;
                            cout << "2. Find shortest path " << endl;
                            cout << "3. Simulate " << endl;
                            cout << "0. Logout" << endl;
                            cin >> choice;

                            if (choice == 1)
                            {
                                cout << endl;
                                system("CLS");
                                graph.printGraph();
                                cout << endl;
                                break;
                            }
                            else if (choice == 2)
                            {
                                cout << endl;
                                system("CLS");
                                graph.pathfinder();
                                cout << endl;
                                break;
                            }
                            else if (choice == 3)
                            {
                                graph.updateBins();
                                graph.updateWeight();
                            }
                            else if (choice == 0)
                            {
                                userType = -1; // Logout
                                system("CLS");
                                cout << "Logged out." << endl;
                                exitFlag = true;
                                break;
                            }
                            else
                            {
                                system("CLS");
                                cout << "invalid input! Try again" << endl;
                                continue;
                            }
                        }
                    }
                    else if (area_choice == 2) // yeh g sectors wala kaam hy lekin first lets implement files
                    {
                        while (1)
                        {
                            cout << "1. Print Graph" << endl;
                            cout << "2. Find shortest path " << endl;
                            cout << "0. Logout" << endl;
                            cin >> choice;

                            if (choice == 1)
                            {
                                cout << endl;
                                system("CLS");
                                graph2.printGraph();
                                cout << endl;
                                break;
                            }
                            else if (choice == 2)
                            {
                                cout << endl;
                                system("CLS");
                                graph2.pathfinder();
                                cout << endl;
                                break;
                            }
                            else if (choice == 3)
                            {
                                graph2.updateBins();
                                graph2.updateWeight();
                            }
                            else if (choice == 0)
                            {
                                userType = -1; // Logout
                                system("CLS");
                                cout << "Logged out." << endl;
                                exitFlag = true;
                                break;
                            }
                            else
                            {
                                system("CLS");
                                cout << "invalid input! Try again" << endl;
                                continue;
                            }
                        }
                    }
                    else if (area_choice == 3) // yeh g sectors wala kaam hy lekin first lets implement files
                    {
                        while (1)
                        {
                            cout << "1. Print Graph" << endl;
                            cout << "2. Find shortest path " << endl;
                            cout << "0. Logout" << endl;
                            cin >> choice;

                            if (choice == 1)
                            {
                                cout << endl;
                                system("CLS");
                                graph3.printGraph();
                                cout << endl;
                                break;
                            }
                            else if (choice == 2)
                            {
                                cout << endl;
                                system("CLS");
                                graph3.pathfinder();
                                cout << endl;
                                break;
                            }
                            else if (choice == 3)
                            {
                                graph3.updateBins();
                                graph3.updateWeight();
                            }
                            else if (choice == 0)
                            {
                                userType = -1; // Logout
                                system("CLS");
                                cout << "Logged out." << endl;
                                exitFlag = true;
                                break;
                            }
                            else
                            {
                                system("CLS");
                                cout << "invalid input! Try again" << endl;
                                continue;
                            }
                        }
                    }
                    else if (area_choice == 4) // yeh g sectors wala kaam hy lekin first lets implement files
                    {
                        while (1)
                        {
                            cout << "1. Print Graph" << endl;
                            cout << "2. Find shortest path " << endl;
                            cout << "0. Logout" << endl;
                            cin >> choice;

                            if (choice == 1)
                            {
                                cout << endl;
                                system("CLS");
                                graph4.printGraph();
                                cout << endl;
                                break;
                            }
                            else if (choice == 2)
                            {
                                cout << endl;
                                system("CLS");
                                graph4.pathfinder();
                                graph4.updateWeight();
                                cout << endl;
                                break;
                            }
                            else if (choice == 3)
                            {
                                graph4.updateBins();
                            }
                            else if (choice == 0)
                            {
                                userType = -1; // Logout
                                cout << "Logged out." << endl;
                                exitFlag = true;
                                break;
                            }
                            else
                            {
                                system("CLS");
                                cout << "invalid input! Try again" << endl;
                                continue;
                            }
                        }
                    }
                    else if (area_choice == 5) // yeh g sectors wala kaam hy lekin first lets implement files
                    {
                        while (1)
                        {
                            cout << "1. Print Graph" << endl;
                            cout << "2. Find shortest path " << endl;
                            cout << "0. Logout" << endl;
                            cin >> choice;

                            if (choice == 1)
                            {
                                cout << endl;
                                system("CLS");
                                graph5.printGraph();
                                cout << endl;
                                break;
                            }
                            else if (choice == 2)
                            {
                                cout << endl;
                                system("CLS");
                                graph5.pathfinder();
                                cout << endl;
                                break;
                            }
                            else if (choice == 3)
                            {
                                graph5.updateBins();
                                graph5.updateWeight();
                            }
                            else if (choice == 0)
                            {
                                userType = -1; // Logout
                                system("CLS");
                                cout << "Logged out." << endl;
                                exitFlag = true;
                                break;
                            }
                            else
                            {
                                system("CLS");
                                cout << "invalid input! Try again" << endl;
                                continue;
                            }
                        }
                    }
                }
                else if (temp == 2) {
                    c.alert(graph);
                    c.alert(graph2);
                    c.alert(graph3);
                    c.alert(graph4);
                    c.alert(graph5);
                    continue;
                }
                else if (temp == 0)
                {
                    userType = -1; // Logout
                    cout << "Logged out." << endl;
                    exitFlag = true;
                }
                else
                {
                    cout << "Invalid Input" << endl;
                }
            }
            else if (userType == 2)
            {
                //cout<<"Truck driver = <<"<<t.getTruck_Driver_name()<<endl;
                if (t.getTruck_Driver_name() == "Ali")
                {
                    cout << "1. Find shortest path " << endl;
                    cout << "2. Collect Garbage " << endl;
                    cout << "0. Logout" << endl;
                    cin >> choice;

                    if (choice == 1)
                    {
                        cout << endl;
                        graph.pathfinder();
                        cout << endl;
                    }
                    else if (choice == 2)
                    {
                        graph.emptyBins();
                    }
                    else if (choice == 0)
                    {
                        userType = -1; // Logout
                        cout << "Logged out." << endl;
                        exitFlag = true;
                    }
                }
                else if (t.getTruck_Driver_name() == "Farukh")
                {
                    cout << "1. Find shortest path " << endl;
                    cout << "2. Collect Garbage " << endl;
                    cout << "0. Logout" << endl;
                    cin >> choice;

                    if (choice == 1)
                    {
                        cout << endl;
                        graph2.pathfinder();
                        cout << endl;
                    }
                    else if (choice == 2)
                    {
                        graph2.emptyBins();
                    }
                    else if (choice == 0)
                    {
                        userType = -1; // Logout
                        cout << "Logged out." << endl;
                        exitFlag = true;
                    }
                }
                else if (t.getTruck_Driver_name() == "Ahmed")
                {
                    cout << "1. Find shortest path " << endl;
                    cout << "2. Collect Garbage " << endl;
                    cout << "0. Logout" << endl;
                    cin >> choice;

                    if (choice == 1)
                    {
                        cout << endl;
                        graph3.pathfinder();
                        cout << endl;
                    }
                    else if (choice == 2)
                    {
                        graph3.emptyBins();
                    }
                    else if (choice == 0)
                    {
                        userType = -1; // Logout
                        cout << "Logged out." << endl;
                        exitFlag = true;
                    }
                }
                else if (t.getTruck_Driver_name() == "Saad")
                {
                    cout << "1. Find shortest path " << endl;
                    cout << "2. Collect Garbage " << endl;
                    cout << "0. Logout" << endl;
                    cin >> choice;

                    if (choice == 1)
                    {
                        cout << endl;
                        graph4.pathfinder();
                        cout << endl;
                    }
                    else if (choice == 2)
                    {
                        graph4.emptyBins();
                    }
                    else if (choice == 0)
                    {
                        userType = -1; // Logout
                        cout << "Logged out." << endl;
                        exitFlag = true;
                    }
                }
                else if (t.getTruck_Driver_name() == "Musaab")
                {
                    cout << "1. Find shortest path " << endl;
                    cout << "2. Collect Garbage " << endl;
                    cout << "0. Logout" << endl;
                    cin >> choice;

                    if (choice == 1)
                    {
                        cout << endl;
                        graph5.pathfinder();
                        cout << endl;
                    }
                    else if (choice == 2)
                    {
                        graph5.emptyBins();
                    }
                    else if (choice == 0)
                    {
                        userType = -1; // Logout
                        cout << "Logged out." << endl;
                        exitFlag = true;
                    }
                }
            }
        }
    }
    cout << "Goodbye........." << endl;
    return 0;
}